<?php

namespace Modelo\Servicios;

use App\Servicios\Pista;

class PistaDAO implements InterfazPista
{
    public function insertarPista(Pista $pista): ?Pista
    {
        // TODO: Implement insertarPista() method.
        return null;
    }

    public function modificarPista(Pista $pista): ?Pista
    {
        // TODO: Implement modificarPista() method.
        return null;
    }

    public function borrarPista(Pista $pista): ?Pista
    {
        // TODO: Implement borrarPista() method.
        return null;
    }

    public function borrarPistaPorId(int $idPista): ?Pista
    {
        // TODO: Implement borrarPistaPorId() method.
        return null;
    }

    public function leerPista(int $idPista): ?Pista
    {
        // TODO: Implement leerPista() method.
        return null;
    }

    public function leerTodasLasPistas(): ?array
    {
        // TODO: Implement leerTodasLasPistas() method.
        return null;
    }
}