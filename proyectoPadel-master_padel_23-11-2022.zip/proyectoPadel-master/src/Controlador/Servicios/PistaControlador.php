<?php

namespace Controlador\Servicios;

use Modelo\Servicios\PistaDAO;

class PistaControlador
{
    private pistaDAO $modelo;
    private pistaVista $vista;

    private function generarHorarioMensual(){

    }
}