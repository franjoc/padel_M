<?php

 const NOMBREBD = "padel";
 const HOSTBD = "db";
 const USUARIOBD = "miguel";
 const PASSBD = "leugim";