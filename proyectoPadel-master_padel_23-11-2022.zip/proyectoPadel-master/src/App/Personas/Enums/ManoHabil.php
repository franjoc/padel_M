<?php

namespace App\Personas\Enums;

enum ManoHabil
{
    case Izquierda;
    case Derecha;
    case Ambidiestro;
}
