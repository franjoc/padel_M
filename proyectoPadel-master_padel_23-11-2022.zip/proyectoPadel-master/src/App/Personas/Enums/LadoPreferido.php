<?php

namespace App\Personas\Enums;

enum LadoPreferido
{
    case Izquierdo;
    case Derecho;
    case Indistinto;
}
