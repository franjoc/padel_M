<?php

namespace App\servicios\Enums;

enum TipoPista
{
    case Individual;
    case Dobles;
}
