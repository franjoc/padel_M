# Repositorio de proyecto de Club de Padel
DWES curso 22-23

## Introducción al proyecto
Proyecto de club de Padel como ejemplo de uso de POO en PHP versión 8.

![Diagrama de Clases](src/images/image.png)
